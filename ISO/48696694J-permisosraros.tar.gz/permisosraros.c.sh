#!/bin/bash -u
resultado=$(find $@ -type f ! -user "root" \( ! -perm -u+r -o ! -perm -u+x \) -printf "%u\n")
usuarios=$(echo $resultado | tr " " "\n" | sort -k 1 | uniq)
ejemplo=""
for u in $usuarios
do
		echo $u
		ficheros=$(find $@ -type f -user "$u" \( ! -perm -u+r -o ! -perm -u+x \) -printf "%p ")
		directorio=" "
		for f in $ficheros
		do
			nombre=$(ls -l $f | cut -d " " -f9)
			permisos=$(ls -l $f | cut -d " " -f1)
			dir_auxiliar=$(dirname $f)
			if [ "$dir_auxiliar" != "$directorio" ]
			then
				echo "   $dir_auxiliar:"
				directorio="$dir_auxiliar"
				echo "    $permisos $nombre"
			else
				echo "    $permisos $nombre"
			fi
		done
done

