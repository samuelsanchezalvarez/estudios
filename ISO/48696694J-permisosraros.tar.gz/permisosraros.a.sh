#!/bin/bash -u
find . -type f ! -user "root" \( ! -perm -u+r -o ! -perm -u+w \) -printf "%p %M\n"
