#!/bin/bash -u
resultado=$(find $@ -type f ! -user "root" \( ! -perm -u+r -o ! -perm -u+x \) -printf "%u\n")
usuarios=$(echo $resultado | tr " " "\n" | sort -k 1 | uniq)
ejemplo=""
for u in $usuarios
do
		echo $u
		ficheros=$(find $@ -type f -user "$u" \( ! -perm -u+r -o ! -perm -u+x \) -printf "      %p %M\n")
		echo "$ficheros"
done

