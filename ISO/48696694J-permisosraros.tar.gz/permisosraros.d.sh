#!/bin/bash -u
directorio_inicial="."
for d in $@
do
	if [ ! -d $d ]
	then
		echo "Uno (o varios) de los argumentos no es un directorio" >& 2
		exit 1
	fi
done
if [ $# -ne 0 ]
then
	directorio_inicial=$@
fi
resultado=$(find $@ -type f ! -user "root" \( ! -perm -u+r -o ! -perm -u+x \) -printf "%u\n")
usuarios=$(echo $resultado | tr " " "\n" | sort -k 1 | uniq)
ejemplo=""
for u in $usuarios
do
		echo $u
		ficheros=$(find $@ -type f -user "$u" \( ! -perm -u+r -o ! -perm -u+x \) -printf "%p ")
		directorio=" "
		for f in $ficheros
		do
			nombre=$(ls -l $f | cut -d " " -f9)
			permisos=$(ls -l $f | cut -d " " -f1)
			dir_auxiliar=$(dirname $f)
			if [ "$dir_auxiliar" != "$directorio" ]
			then
				echo "   $dir_auxiliar:"
				directorio="$dir_auxiliar"
				echo "    $permisos $nombre"
			else
				echo "    $permisos $nombre"
			fi
		done
done
exit 0
