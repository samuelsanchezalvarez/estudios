#!/bin/bash -u
cal $1 -m 2 | grep -q 29
