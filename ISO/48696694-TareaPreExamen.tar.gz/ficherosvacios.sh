#!/bin/bash -u
usuarios=$(find $@ -type f -size 0 -printf "%u\n" | sort | uniq)
for u in $usuarios
do
	echo "$u:"
	find $@ -user "$u" -type f -size 0 -printf "\t%p\n"
	total=$(find $@ -user "$u" -type f -size 0 -printf "%p\n" | wc -l)
	echo "Total ficheros: $total"
done
