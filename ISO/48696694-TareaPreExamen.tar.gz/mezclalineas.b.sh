#!/bin/bash -u
if [ $# -ne 2 ]
then
	echo "Uso: mezclalineas.a.sh fichero1 fichero 2" >&2
	exit 1
fi
if [ ! -f $1 ] 
then
	echo "El fichero '$1' no existe o no se puede leer" >&2
	exit 2
fi
if [ -f $2 ]
then
	echo "El fichero '$2' ya existe" >&2
	exit 3
fi
numeros=""
num_lineas=$(cat $1 | wc -l)
for i in $(seq 1 1 $num_lineas) 
do
  	numeros=$(echo $numeros$i)
done
j=0
while [ $j -ne $num_lineas ]
do
	p=$(echo $(($RANDOM%num_lineas+1)))
	echo $numeros | cut -c $p
	j=$(($j+1))
done

