#!/bin/bash -u
if [ $# -ne 2 ]
then
	echo "Uso: mezclalineas.a.sh fichero1 fichero 2" >&2
	exit 1
fi
if [ ! -f $1 ] 
then
	echo "El fichero '$1' no existe o no se puede leer" >&2
	exit 2
fi
if [ -f $2 ]
then
	echo "El fichero '$2' ya existe" >&2
	exit 3
fi
