#!/bin/bash -u
if [ $# -ne 2 ]
then
	echo "Uso: mezclalineas.a.sh fichero1 fichero 2" >&2
	exit 1
fi
if [ ! -f $1 ] 
then
	echo "El fichero '$1' no existe o no se puede leer" >&2
	exit 2
fi
if [ -f $2 ]
then
	echo "El fichero '$2' ya existe" >&2
	exit 3
fi
numeros=""
num_lineas=$(cat $1 | wc -l)
for i in $(seq 1 1 $num_lineas) 
do
  	numeros=$(echo $numeros$i)
done
j=1
while [ $j -le $num_lineas ]
do
	nlinea=0
	p=$(echo $(($RANDOM%num_lineas+1)))
	linea_a_mostrar=$(echo $numeros | cut -c $p)
	cat $1 | (while read l
		do
			nlinea=$(($nlinea+1))
			if [ $nlinea -eq $p ]
			then
				echo "Linea $j: Linea $p del fichero '$1'"
				echo $l >> $2
			fi
		done;)	
	j=$(($j+1))
done
